import { motion, useScroll, useTransform } from "motion/react";

export function App() {
  const { scrollY } = useScroll();

  const logoWidth = useTransform(scrollY, [0, 100], [0, 190]);
  // const logoMarginLeft = useTransform(scrollY, [0, 100], [0, 24]);
  const logoMarginRight = useTransform(scrollY, [0, 100], [0, 36]);

  return (
    <>
      {/* header topbar */}
      <div className="header-top">
        <div className="container">
          <div className="py-4 flex items-center ">
            <a href="">
              <img src="/logo.svg" alt="" />
            </a>
          </div>
        </div>
      </div>
      <header className="sticky top-0 w-full bg-white z-10">
        {/* main header */}
        <div className="container">
          <div className="py-4 flex items-center">
            <button className="h-10 px-5 bg-yellow-500 rounded-xl mr-6">
              Catalog
            </button>
            <motion.a
              href="#!"
              style={{
                width: logoWidth,
                marginRight: logoMarginRight,
                // marginLeft: logoMarginLeft,
              }}
              className="ml-6 mr-9"
            >
              <img src="/logo.svg" alt="" />
            </motion.a>
            <nav>
              <ul className="flex items-center gap-6">
                <li>
                  <a href="#!">About us</a>
                </li>
                <li>
                  <a href="#!">Media</a>
                </li>
                <li>
                  <a href="#!">Service</a>
                </li>
                <li>
                  <a href="#!">Pairing</a>
                </li>
                <li>
                  <a href="#!">News</a>
                </li>
                <li>
                  <a href="#!">Contacts</a>
                </li>
              </ul>
            </nav>
          </div>
        </div>
      </header>
      <main>
        <section className="h-screen bg-red-300"></section>
        <section className="h-screen bg-green-300"></section>
        <section className="h-screen bg-blue-300"></section>
      </main>
    </>
  );
}
