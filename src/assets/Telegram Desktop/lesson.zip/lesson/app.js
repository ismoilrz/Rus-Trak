const translations = {
  uz: {
    title: "Bosh sahifa",
    description:
      "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ex laborum nisi at repellendus quaerat tempore corrupti perferendis veritatis? Accusantium, nisi!",
    description_big:
      "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ex laborum nisi at repellendus quaerat tempore corrupti perferendis veritatis? Accusantium, nisi!. Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ex laborum nisi at repellendus quaerat tempore corrupti perferendis veritatis? Accusantium, nisi!",
  },
  ru: {
    title: "Домашняя страница",
    description:
      "Давно выяснено, что при оценке дизайна и композиции читаемый текст мешает сосредоточиться. Lorem Ipsum используют потому, что тот обеспечивает более или менее стандартное заполнение шаблона, а также реальное распределение букв и пробелов в абзацах, которое не получается при простой дубликации Здесь ваш текст.. Здесь ваш текст.. Здесь ваш текст.. Многие программы электронной вёрстки",
    description_big:
      "Давно выяснено, что при оценке дизайна и композиции читаемый текст мешает сосредоточиться. Lorem Ipsum используют потому, что тот обеспечивает более или менее стандартное заполнение шаблона, а также реальное распределение букв и пробелов в абзацах, которое не получается при простой дубликации Здесь ваш текст.. Здесь ваш текст.. Здесь ваш текст.. Многие программы электронной вёрстки и редакторы HTML используют Lorem Ipsum в качестве текста по умолчанию, так что поиск по ключевым словам lorem ipsum сразу показывает, как много веб-страниц всё ещё дожидаются своего настоящего рождения. За прошедшие годы текст Lorem Ipsum получил много версий. Некоторые версии появились по ошибке, некоторые - намеренно (например, юмористические варианты).",
  },
  en: {
    title: "Home page",
    description:
      "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ex laborum nisi at repellendus quaerat tempore corrupti perferendis veritatis? Accusantium, nisi!. Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ex laborum nisi at repellendus quaerat tempore corrupti perferendis veritatis? Accusantium, nisi!",
      description_big:
      "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ex laborum nisi at repellendus quaerat tempore corrupti perferendis veritatis? Accusantium, nisi!. Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ex laborum nisi at repellendus quaerat tempore corrupti perferendis veritatis? Accusantium, nisi!",
  },
};

const langButtons = document.querySelectorAll("[data-lang]");
const elements = document.querySelectorAll("[data-key]");

let defaultLanguage = "uz";
let currentLanguage = localStorage.getItem("language");

window.addEventListener("DOMContentLoaded", () => {
  let selectedLanguage = currentLanguage || defaultLanguage;
  elements.forEach((element) => {
    const key = element.getAttribute("data-key");
    const translation =
      translations?.[selectedLanguage] &&
      translations?.[selectedLanguage]?.[key];

    if (element) {
      element.textContent = translation;
    }
  });
});

langButtons.forEach((button) => {
  const language = button.getAttribute("data-lang");
  button.addEventListener("click", () => {
    changeLanguage(language);
  });
});

function changeLanguage(language) {
  localStorage.removeItem("language");
  localStorage.setItem("language", language);
  window.location.reload();
}
