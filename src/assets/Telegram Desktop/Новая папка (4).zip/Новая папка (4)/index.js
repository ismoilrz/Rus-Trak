const contacts = [
    {
        id: 1,
        name: "Ali",
        phone: "998901234567",
        email: "ali@example.com",
    },
    {
        id: 2,
        name: "Vali",
        phone: "998909876543",
        email: "vali@example.com",
    },
];

// 1️⃣ getAllContacts
function getAllContacts() {
    return contacts;
    // TODO: barcha contactlarni qaytarish
}

// 2️⃣ getContactById
function getContactById(id) {
    return contacts.find(contact => contact.id === id);
    // TODO: id bo'yicha contact topish
}

// 3️⃣ createContact
function createContact(newContact) {
    const id = contacts.length ? contacts[contacts.length - 1].id + 1 : 1
    const contact = { id, ...newContact }
    contacts.push(contact);
    return contact;
    // TODO: 
    // yangi contact qo'shish 
    // id auto generate bo'lishi kerak
}

// 4️⃣ updateContact
function updateContact(id, updatedData) {
    const contact = getContactById(id);
    if (!contact) {
        return null;
    }
    Object.assign(contact, updatedData);
    return contact;
    // TODO: 
    // contactni update qilish
}

// 5️⃣ deleteContact
function deleteContact(id) {
    const contact = getContactById(id);
    if (!contact) {
        return null;
    }
    contacts.splice(contacts.indexOf(contact), 1);
    return contact;
    // TODO: 
    // contactni o'chirish
}

// Tekshirish

console.log("All contacts:");
console.log(getAllContacts());

console.log("\nContact by ID:");
console.log(getContactById(1));

console.log("\nCreate contact:");
const newContact = createContact({
    name: "Sadulla",
    phone: "+998 93 663 07 85",
    email: "sadullayev813@gmail.com",
});
console.log(newContact);

console.log("\nUpdate contact:");
const updated = updateContact(1, {
    name: "Ali Valiyev",
});
console.log(updated);

console.log("\nDelete contact:");
const deleted = deleteContact(2);
console.log(deleted);

console.log("\nFinal contacts:");
console.log(getAllContacts());

